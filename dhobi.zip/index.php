<?php
header('location:./html/index.php');
?>