 <!---About Us--->
 <section class="footer">
        <h4>About Us</h4>
        <p>Visit us or contact us for any type of Garments cleaning or Household cleaing you desire.</p>

        <div class="icons">
         <a href="https://www.facebook.com/"> <i class="fab fa-facebook" style="color: blue;"></i></a>
         <a href="https://www.instagram.com/"><i class="fab fa-instagram"style="color: red;"></i></a>
         <a href="https://twitter.com"> <i class="fab fa-twitter" style="color: deepskyblue;"></i></a>
         <a href="https://www.linkedin.com/"><i class="fab fa-linkedin"style="color: cornflowerblue;"></i></a>
        </div>
      </section>
        

        <!---- Java script for Toggle menu--->
        <script>
            var navlinlinks= document.getElementById("navlinks");
            function showMenu(){
                navlinlinks.style.right="0";
            }
            function hideMenu(){
                navlinlinks.style.right="-200px";
            }
        </script>

    </body>
</html>