<?php
session_start();
include('../include/header.php');
?>
<section class="sub-header">
  <?php
  include('../include/nav.php');
  ?>
  <h1>About Us</h1>
</section>

<!----about us content---->

<section class="about-us">
  <div class="row">
    <div class="about-col">
      <h1>We provide you Washing services</h1>
      <p>Visit us or contact us for any type of Garments cleaning or Household cleaing you desire.
Dhobi benefits you with the preference to decide on the type of cleaning service you want in the cost-effective approach
We are also available to serve you according to your schedule. Looking ahead to hearing from you.</p>
      <a href="./index.php" class="hi-btn red-btn">Visit Us</a>
    </div>
    <div class="about-col">
      <img src="../assets/About.jpg">
    </div>
  </div>
</section>


<!---About Us--->
<?php
include('../include/footer.php');
?>